-- ALMOGHANI Streaming Platform
-- PostgreSQL 15+
-- UTF-8 / Arabic-ready schema
-- Apply with: psql "$DATABASE_URL" -f schema.sql

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE SCHEMA IF NOT EXISTS almoghani;
SET search_path TO almoghani, public;

-- =========================
-- Enumerations
-- =========================

CREATE TYPE user_role AS ENUM ('viewer', 'editor', 'moderator', 'admin');
CREATE TYPE user_status AS ENUM ('active', 'suspended', 'pending', 'deleted');
CREATE TYPE content_type AS ENUM ('movie', 'series', 'episode', 'live_channel');
CREATE TYPE content_status AS ENUM ('draft', 'published', 'archived');
CREATE TYPE stream_status AS ENUM ('offline', 'scheduled', 'live', 'ended', 'error');
CREATE TYPE visibility_type AS ENUM ('public', 'private', 'unlisted');
CREATE TYPE media_kind AS ENUM ('poster', 'backdrop', 'thumbnail', 'logo', 'avatar', 'subtitle', 'video');
CREATE TYPE watch_event_type AS ENUM ('started', 'progress', 'completed', 'abandoned');

-- =========================
-- Shared trigger
-- =========================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- =========================
-- Users and access control
-- =========================

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email CITEXT NOT NULL UNIQUE,
  password_hash TEXT,
  display_name VARCHAR(120) NOT NULL,
  avatar_url TEXT,
  role user_role NOT NULL DEFAULT 'viewer',
  status user_status NOT NULL DEFAULT 'active',
  preferred_locale VARCHAR(10) NOT NULL DEFAULT 'ar',
  timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Riyadh',
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  CONSTRAINT users_email_length CHECK (length(email::text) <= 320),
  CONSTRAINT users_display_name_not_blank CHECK (length(btrim(display_name)) > 0)
);

CREATE TABLE refresh_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE user_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_name VARCHAR(120),
  ip_address INET,
  user_agent TEXT,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =========================
-- Taxonomy and media
-- =========================

CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar VARCHAR(100) NOT NULL,
  name_en VARCHAR(100),
  slug CITEXT NOT NULL UNIQUE,
  icon_name VARCHAR(80),
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT categories_name_ar_not_blank CHECK (length(btrim(name_ar)) > 0)
);

CREATE TABLE media_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind media_kind NOT NULL,
  storage_key TEXT NOT NULL UNIQUE,
  public_url TEXT NOT NULL,
  mime_type VARCHAR(120),
  width INTEGER,
  height INTEGER,
  duration_seconds INTEGER,
  size_bytes BIGINT,
  alt_text_ar VARCHAR(300),
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT media_dimensions_positive CHECK (
    (width IS NULL OR width > 0) AND (height IS NULL OR height > 0)
  ),
  CONSTRAINT media_size_positive CHECK (size_bytes IS NULL OR size_bytes >= 0)
);

-- =========================
-- Channels and live streaming
-- =========================

CREATE TABLE channels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar VARCHAR(160) NOT NULL,
  name_en VARCHAR(160),
  slug CITEXT NOT NULL UNIQUE,
  description_ar TEXT,
  logo_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL,
  category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
  stream_key_hash TEXT UNIQUE,
  playback_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  visibility visibility_type NOT NULL DEFAULT 'public',
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT channels_name_ar_not_blank CHECK (length(btrim(name_ar)) > 0)
);

CREATE TABLE live_streams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  title_ar VARCHAR(200) NOT NULL,
  description_ar TEXT,
  status stream_status NOT NULL DEFAULT 'offline',
  playback_url TEXT,
  ingest_started_at TIMESTAMPTZ,
  scheduled_start_at TIMESTAMPTZ,
  actual_start_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  current_viewers INTEGER NOT NULL DEFAULT 0,
  peak_viewers INTEGER NOT NULL DEFAULT 0,
  total_views BIGINT NOT NULL DEFAULT 0,
  thumbnail_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT live_streams_viewers_nonnegative CHECK (current_viewers >= 0 AND peak_viewers >= 0 AND total_views >= 0),
  CONSTRAINT live_streams_title_not_blank CHECK (length(btrim(title_ar)) > 0)
);

CREATE TABLE stream_viewer_snapshots (
  id BIGSERIAL PRIMARY KEY,
  stream_id UUID NOT NULL REFERENCES live_streams(id) ON DELETE CASCADE,
  captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  viewers INTEGER NOT NULL CHECK (viewers >= 0)
);

-- =========================
-- VOD content: movies, series, episodes
-- =========================

CREATE TABLE content_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type content_type NOT NULL,
  title_ar VARCHAR(200) NOT NULL,
  title_en VARCHAR(200),
  slug CITEXT NOT NULL UNIQUE,
  synopsis_ar TEXT,
  release_year SMALLINT,
  age_rating VARCHAR(20),
  duration_seconds INTEGER,
  status content_status NOT NULL DEFAULT 'draft',
  visibility visibility_type NOT NULL DEFAULT 'public',
  poster_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL,
  backdrop_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL,
  trailer_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL,
  published_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT content_title_not_blank CHECK (length(btrim(title_ar)) > 0),
  CONSTRAINT content_release_year_valid CHECK (release_year IS NULL OR release_year BETWEEN 1888 AND 2200),
  CONSTRAINT content_duration_valid CHECK (duration_seconds IS NULL OR duration_seconds > 0)
);

CREATE TABLE content_categories (
  content_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (content_id, category_id)
);

CREATE TABLE series (
  content_id UUID PRIMARY KEY REFERENCES content_items(id) ON DELETE CASCADE,
  total_seasons INTEGER NOT NULL DEFAULT 0 CHECK (total_seasons >= 0)
);

CREATE TABLE seasons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  series_id UUID NOT NULL REFERENCES series(content_id) ON DELETE CASCADE,
  season_number INTEGER NOT NULL CHECK (season_number > 0),
  title_ar VARCHAR(200),
  synopsis_ar TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (series_id, season_number)
);

CREATE TABLE episodes (
  content_id UUID PRIMARY KEY REFERENCES content_items(id) ON DELETE CASCADE,
  season_id UUID NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
  episode_number INTEGER NOT NULL CHECK (episode_number > 0),
  video_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL,
  runtime_seconds INTEGER CHECK (runtime_seconds IS NULL OR runtime_seconds > 0),
  UNIQUE (season_id, episode_number)
);

CREATE TABLE movie_media (
  content_id UUID PRIMARY KEY REFERENCES content_items(id) ON DELETE CASCADE,
  video_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL,
  subtitles_asset_id UUID REFERENCES media_assets(id) ON DELETE SET NULL
);

-- =========================
-- User interaction and playback
-- =========================

CREATE TABLE favorites (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, content_id)
);

CREATE TABLE watch_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
  progress_seconds INTEGER NOT NULL DEFAULT 0 CHECK (progress_seconds >= 0),
  duration_seconds INTEGER CHECK (duration_seconds IS NULL OR duration_seconds > 0),
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  last_watched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, content_id)
);

CREATE TABLE watch_events (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  content_id UUID REFERENCES content_items(id) ON DELETE SET NULL,
  stream_id UUID REFERENCES live_streams(id) ON DELETE SET NULL,
  event_type watch_event_type NOT NULL,
  position_seconds INTEGER CHECK (position_seconds IS NULL OR position_seconds >= 0),
  session_id UUID REFERENCES user_sessions(id) ON DELETE SET NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT watch_event_target CHECK (content_id IS NOT NULL OR stream_id IS NOT NULL)
);

CREATE TABLE ratings (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_ar TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, content_id)
);

-- =========================
-- Admin audit and platform settings
-- =========================

CREATE TABLE audit_logs (
  id BIGSERIAL PRIMARY KEY,
  actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id UUID,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  ip_address INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE platform_settings (
  key VARCHAR(100) PRIMARY KEY,
  value JSONB NOT NULL,
  updated_by UUID REFERENCES users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =========================
-- Indexes
-- =========================

CREATE INDEX idx_users_role_status ON users(role, status) WHERE deleted_at IS NULL;
CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id, expires_at);
CREATE INDEX idx_sessions_user_last_seen ON user_sessions(user_id, last_seen_at DESC);
CREATE INDEX idx_categories_active_order ON categories(is_active, sort_order);
CREATE INDEX idx_channels_category_active ON channels(category_id, is_active);
CREATE INDEX idx_channels_visibility ON channels(visibility) WHERE is_active = TRUE;
CREATE INDEX idx_live_streams_status ON live_streams(status, scheduled_start_at);
CREATE INDEX idx_live_streams_channel_created ON live_streams(channel_id, created_at DESC);
CREATE INDEX idx_viewer_snapshots_stream_time ON stream_viewer_snapshots(stream_id, captured_at DESC);
CREATE INDEX idx_content_status_published ON content_items(status, published_at DESC);
CREATE INDEX idx_content_type_status ON content_items(type, status);
CREATE INDEX idx_content_categories_category ON content_categories(category_id, content_id);
CREATE INDEX idx_seasons_series ON seasons(series_id, season_number);
CREATE INDEX idx_episodes_season ON episodes(season_id, episode_number);
CREATE INDEX idx_favorites_user_created ON favorites(user_id, created_at DESC);
CREATE INDEX idx_history_user_recent ON watch_history(user_id, last_watched_at DESC);
CREATE INDEX idx_watch_events_content_time ON watch_events(content_id, occurred_at DESC);
CREATE INDEX idx_watch_events_stream_time ON watch_events(stream_id, occurred_at DESC);
CREATE INDEX idx_watch_events_time ON watch_events(occurred_at DESC);
CREATE INDEX idx_audit_entity_time ON audit_logs(entity_type, entity_id, created_at DESC);
CREATE INDEX idx_audit_actor_time ON audit_logs(actor_user_id, created_at DESC);

-- Arabic and English search indexes.
CREATE INDEX idx_content_search ON content_items
USING GIN (to_tsvector('simple', coalesce(title_ar, '') || ' ' || coalesce(title_en, '') || ' ' || coalesce(synopsis_ar, '')));

-- =========================
-- Updated-at triggers
-- =========================

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_categories_updated_at BEFORE UPDATE ON categories
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_channels_updated_at BEFORE UPDATE ON channels
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_live_streams_updated_at BEFORE UPDATE ON live_streams
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_content_items_updated_at BEFORE UPDATE ON content_items
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_ratings_updated_at BEFORE UPDATE ON ratings
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- =========================
-- Starter seed data
-- =========================

INSERT INTO categories (name_ar, name_en, slug, icon_name, sort_order) VALUES
  ('قنوات', 'Channels', 'channels', 'tv', 10),
  ('مسلسلات', 'Series', 'series', 'clapperboard', 20),
  ('أفلام', 'Movies', 'movies', 'film', 30),
  ('رياضة', 'Sports', 'sports', 'trophy', 40),
  ('موسيقى', 'Music', 'music', 'music-2', 50),
  ('أخبار', 'News', 'news', 'newspaper', 60)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO platform_settings (key, value) VALUES
  ('brand', '{"name":"ALMOGHANI","default_locale":"ar","direction":"rtl"}'::jsonb),
  ('streaming', '{"default_live_viewer_limit":100000,"heartbeat_seconds":30}'::jsonb),
  ('content', '{"default_visibility":"public","require_moderation":true}'::jsonb)
ON CONFLICT (key) DO NOTHING;

COMMIT;

-- Recommended production follow-ups:
-- 1. Store only password hashes (Argon2id or bcrypt), never raw passwords.
-- 2. Keep stream_key_hash only; never expose an ingest key through public APIs.
-- 3. Add Row Level Security if the application connects with a shared DB role.
-- 4. Run migrations through a tool such as Prisma, Drizzle, Flyway, or Liquibase.
-- 5. Archive watch_events and stream_viewer_snapshots periodically at scale.
